package main

import (
	"archive/zip"
	"bytes"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strings"
	"sync"
	"time"
)

const maxBytes = 20 * 1024 * 1024
const protocol = "chip-counter-pc-v1"

var transferID = regexp.MustCompile(`^[a-f0-9]{32}$`)

type Config struct {
	ReceiverID string `json:"receiverId"`
	Token      string `json:"token"`
	Folder     string `json:"folder"`
	Port       int    `json:"port"`
}
type Receipt struct {
	ID     string `json:"transferId"`
	Hash   string `json:"sha256"`
	Path   string `json:"path"`
	Count  int    `json:"count"`
	Stored bool   `json:"stored"`
}
type Server struct {
	mu    sync.Mutex
	base  string
	cfg   Config
	admin string
}

func randomID() string {
	b := make([]byte, 16)
	if _, e := rand.Read(b); e != nil {
		panic(e)
	}
	return hex.EncodeToString(b)
}
func atomicWrite(path string, data []byte) error {
	f, e := os.CreateTemp(filepath.Dir(path), ".chip-*.part")
	if e != nil {
		return e
	}
	name := f.Name()
	defer os.Remove(name)
	if e = f.Chmod(0600); e == nil {
		_, e = f.Write(data)
	}
	if e == nil {
		e = f.Sync()
	}
	ce := f.Close()
	if e == nil {
		e = ce
	}
	if e != nil {
		return e
	}
	return os.Rename(name, path)
}
func writeJSON(path string, v interface{}) error {
	b, e := json.MarshalIndent(v, "", "  ")
	if e != nil {
		return e
	}
	return atomicWrite(path, b)
}
func newServer(base string) (*Server, error) {
	if e := os.MkdirAll(base, 0700); e != nil {
		return nil, e
	}
	s := &Server{base: base, admin: randomID()}
	p := filepath.Join(base, "receiver-config.json")
	b, e := os.ReadFile(p)
	if errors.Is(e, os.ErrNotExist) {
		s.cfg = Config{randomID(), randomID(), filepath.Join(base, "MES_업로드"), 8765}
		if e = writeJSON(p, s.cfg); e != nil {
			return nil, e
		}
	} else if e != nil {
		return nil, e
	} else if e = json.Unmarshal(b, &s.cfg); e != nil {
		return nil, e
	}
	if !transferID.MatchString(s.cfg.ReceiverID) || !transferID.MatchString(s.cfg.Token) || s.cfg.Port < 1024 || s.cfg.Port > 65535 || !filepath.IsAbs(s.cfg.Folder) {
		return nil, errors.New("receiver-config.json 설정이 올바르지 않습니다")
	}
	if e = os.MkdirAll(filepath.Join(base, "receipts"), 0700); e != nil {
		return nil, e
	}
	return s, nil
}
func answer(w http.ResponseWriter, status int, v interface{}) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}
func failure(w http.ResponseWriter, status int, msg string) {
	answer(w, status, map[string]interface{}{"ok": false, "message": msg})
}
func authorized(actual, expected string) bool {
	return len(actual) == len(expected) && subtle.ConstantTimeCompare([]byte(actual), []byte(expected)) == 1
}
func (s *Server) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("Referrer-Policy", "no-referrer")
	if strings.HasPrefix(r.URL.Path, "/api/v1/") {
		s.mu.Lock()
		defer s.mu.Unlock()
		if !authorized(r.Header.Get("X-Chip-Token"), s.cfg.Token) {
			failure(w, 401, "연결 코드가 맞지 않습니다")
			return
		}
		if r.URL.Path == "/api/v1/health" && r.Method == "GET" {
			answer(w, 200, map[string]interface{}{"ok": true, "protocol": protocol, "receiverId": s.cfg.ReceiverID, "folder": s.cfg.Folder})
			return
		}
		if r.URL.Path == "/api/v1/uploads" && r.Method == "POST" {
			s.upload(w, r)
			return
		}
		failure(w, 404, "지원하지 않는 요청입니다")
		return
	}
	host, _, e := net.SplitHostPort(r.RemoteAddr)
	if e != nil || net.ParseIP(host) == nil || !net.ParseIP(host).IsLoopback() {
		failure(w, 403, "PC 설정은 수신 노트북에서만 열 수 있습니다")
		return
	}
	if r.URL.Path == "/" && r.Method == "GET" {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Content-Security-Policy", "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'")
		w.Header().Set("Cache-Control", "no-store")
		io.WriteString(w, dashboard)
		return
	}
	if !authorized(r.Header.Get("X-Admin-Token"), s.admin) {
		failure(w, 403, "PC 설정 화면을 다시 열어주세요")
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if r.URL.Path == "/settings" && r.Method == "GET" {
		answer(w, 200, map[string]interface{}{"ok": true, "config": s.cfg, "addresses": addresses(s.cfg.Port)})
		return
	}
	if r.URL.Path == "/settings" && r.Method == "POST" {
		var v struct {
			Folder string `json:"folder"`
		}
		if e = json.NewDecoder(http.MaxBytesReader(w, r.Body, 8192)).Decode(&v); e != nil || !filepath.IsAbs(strings.TrimSpace(v.Folder)) {
			failure(w, 400, "저장할 폴더의 전체 경로를 입력하세요")
			return
		}
		folder := filepath.Clean(strings.TrimSpace(v.Folder))
		if e = os.MkdirAll(folder, 0700); e != nil {
			failure(w, 400, "폴더를 만들 수 없습니다: "+e.Error())
			return
		}
		test, e := os.CreateTemp(folder, ".chip-write-test-*")
		if e != nil {
			failure(w, 400, "이 폴더에 쓰기 권한이 없습니다")
			return
		}
		test.Close()
		os.Remove(test.Name())
		cfg := s.cfg
		cfg.Folder = folder
		if e = writeJSON(filepath.Join(s.base, "receiver-config.json"), cfg); e != nil {
			failure(w, 500, "설정을 저장하지 못했습니다")
			return
		}
		s.cfg = cfg
		answer(w, 200, map[string]interface{}{"ok": true, "folder": folder})
		return
	}
	failure(w, 404, "지원하지 않는 요청입니다")
}
func (s *Server) upload(w http.ResponseWriter, r *http.Request) {
	if r.Header.Get("X-Receiver-ID") != s.cfg.ReceiverID {
		failure(w, 409, "받는 PC가 변경되었습니다. 앱에서 PC 설정을 다시 확인하세요")
		return
	}
	id, hash := r.Header.Get("X-Transfer-ID"), r.Header.Get("X-Content-SHA256")
	if !transferID.MatchString(id) || len(hash) != 64 {
		failure(w, 400, "전송 번호 또는 해시가 올바르지 않습니다")
		return
	}
	b, e := io.ReadAll(http.MaxBytesReader(w, r.Body, maxBytes))
	if e != nil {
		failure(w, 413, "파일은 20MB 이하만 받을 수 있습니다")
		return
	}
	sum := sha256.Sum256(b)
	if hash != hex.EncodeToString(sum[:]) {
		failure(w, 400, "파일 무결성 확인에 실패했습니다")
		return
	}
	count, e := validateWorkbook(b)
	if e != nil {
		failure(w, 400, e.Error())
		return
	}
	receiptPath := filepath.Join(s.base, "receipts", id+".json")
	var receipt Receipt
	old, e := os.ReadFile(receiptPath)
	if e == nil {
		if json.Unmarshal(old, &receipt) != nil || receipt.ID != id {
			failure(w, 500, "수신 기록을 읽지 못했습니다")
			return
		}
		if receipt.Hash != hash {
			failure(w, 409, "같은 전송 번호로 다른 파일을 보낼 수 없습니다")
			return
		}
		if receipt.Stored {
			answer(w, 200, map[string]interface{}{"ok": true, "protocol": protocol, "receiverId": s.cfg.ReceiverID, "transferId": id, "sha256": hash, "count": receipt.Count, "path": receipt.Path, "duplicate": true})
			return
		}
	} else if !errors.Is(e, os.ErrNotExist) {
		failure(w, 500, "수신 기록을 읽지 못했습니다")
		return
	} else {
		receipt = Receipt{ID: id, Hash: hash, Count: count, Path: filepath.Join(s.cfg.Folder, "Chip_Counter_"+time.Now().Format("20060102_150405")+"_"+id+".xlsx")}
		if e = writeJSON(receiptPath, receipt); e != nil {
			failure(w, 500, "수신 기록을 준비하지 못했습니다")
			return
		}
	}
	if e = os.MkdirAll(filepath.Dir(receipt.Path), 0700); e != nil {
		failure(w, 500, "저장 폴더를 열지 못했습니다")
		return
	}
	existing, e := os.ReadFile(receipt.Path)
	if e == nil {
		h := sha256.Sum256(existing)
		if hex.EncodeToString(h[:]) != hash {
			failure(w, 409, "동일 이름의 다른 파일이 있습니다. PC에서 확인하세요")
			return
		}
	} else if !errors.Is(e, os.ErrNotExist) {
		failure(w, 500, "파일을 확인하지 못했습니다")
		return
	} else if e = atomicWrite(receipt.Path, b); e != nil {
		failure(w, 500, "Excel 파일을 저장하지 못했습니다: "+e.Error())
		return
	}
	receipt.Stored = true
	if e = writeJSON(receiptPath, receipt); e != nil {
		failure(w, 500, "파일은 저장됐으나 수신 완료 기록에 실패했습니다. 다시 전송하세요")
		return
	}
	log.Printf("Excel 저장 완료: %d건 / %s", count, receipt.Path)
	answer(w, 200, map[string]interface{}{"ok": true, "protocol": protocol, "receiverId": s.cfg.ReceiverID, "transferId": id, "sha256": hash, "count": count, "path": receipt.Path, "duplicate": false})
}

// Validate the six existing Excel columns without rewriting the received workbook.
func validateWorkbook(b []byte) (int, error) {
	z, e := zip.NewReader(bytes.NewReader(b), int64(len(b)))
	if e != nil {
		return 0, errors.New("Excel 파일이 올바르지 않습니다")
	}
	if len(z.File) > 32 {
		return 0, errors.New("Excel 파일 구조가 올바르지 않습니다")
	}
	var data []byte
	var total uint64
	required := map[string]bool{"[Content_Types].xml": false, "xl/workbook.xml": false, "xl/worksheets/sheet1.xml": false}
	for _, f := range z.File {
		total += f.UncompressedSize64
		if total > 40*1024*1024 {
			return 0, errors.New("Excel 내용이 너무 큽니다")
		}
		if _, ok := required[f.Name]; ok {
			required[f.Name] = true
		}
		if f.Name == "xl/worksheets/sheet1.xml" {
			r, err := f.Open()
			if err != nil {
				return 0, err
			}
			data, err = io.ReadAll(io.LimitReader(r, 40*1024*1024+1))
			r.Close()
			if err != nil || len(data) > 40*1024*1024 {
				return 0, errors.New("Excel 내용을 읽지 못했습니다")
			}
		}
	}
	for _, ok := range required {
		if !ok {
			return 0, errors.New("필수 Excel 항목이 없습니다")
		}
	}
	type Cell struct {
		Type    string  `xml:"t,attr"`
		Formula *string `xml:"f"`
		Value   string  `xml:"v"`
		Text    string  `xml:"is>t"`
	}
	var sheet struct {
		Rows []struct {
			Cells []Cell `xml:"c"`
		} `xml:"sheetData>row"`
	}
	if e = xml.Unmarshal(data, &sheet); e != nil || len(sheet.Rows) < 2 {
		return 0, errors.New("Excel에 측정 데이터가 없습니다")
	}
	want := []string{"측정일시", "기종", "Sheet", "총 수량", "불량 수량", "실제 수량"}
	for i, row := range sheet.Rows {
		if len(row.Cells) != 6 {
			return 0, errors.New("Excel 열 수가 기존 양식과 다릅니다")
		}
		for j, c := range row.Cells {
			if c.Formula != nil {
				return 0, errors.New("수식은 전송할 수 없습니다")
			}
			if i == 0 && c.Text != want[j] {
				return 0, errors.New("Excel 열 순서가 기존 양식과 다릅니다")
			}
		}
	}
	return len(sheet.Rows) - 1, nil
}
func addresses(port int) []string {
	out := []string{}
	all, _ := net.InterfaceAddrs()
	for _, a := range all {
		ip, _, e := net.ParseCIDR(a.String())
		if e == nil && ip.To4() != nil && !ip.IsLoopback() && (ip.IsPrivate() || ip.IsLinkLocalUnicast()) {
			out = append(out, fmt.Sprintf("%s:%d", ip.String(), port))
		}
	}
	return out
}
func main() {
	base, e := os.Executable()
	if e != nil {
		log.Fatal(e)
	}
	base = filepath.Dir(base)
	if v := os.Getenv("CHIP_RECEIVER_HOME"); v != "" {
		base = v
	}
	s, e := newServer(base)
	if e != nil {
		log.Fatal(e)
	}
	url := fmt.Sprintf("http://127.0.0.1:%d/#%s", s.cfg.Port, s.admin)
	listener, e := net.Listen("tcp4", fmt.Sprintf("0.0.0.0:%d", s.cfg.Port))
	if e != nil {
		fmt.Println("수신기를 시작하지 못했습니다. 이미 실행 중인지 확인하세요:", e)
		time.Sleep(15 * time.Second)
		return
	}
	fmt.Println("Chip Counter PC Receiver v1.0\n이 창이 열려 있어야 태블릿에서 파일을 받을 수 있습니다.")
	fmt.Println("PC 설정 화면:", url)
	fmt.Println("태블릿에 입력할 PC 주소:", addresses(s.cfg.Port))
	fmt.Println("연결 코드:", s.cfg.Token)
	fmt.Println("Excel 저장 폴더:", s.cfg.Folder)
	if runtime.GOOS == "windows" {
		exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
	}
	server := &http.Server{Handler: s, ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 60 * time.Second, WriteTimeout: 60 * time.Second, IdleTimeout: 30 * time.Second, MaxHeaderBytes: 8192}
	log.Fatal(server.Serve(listener))
}

const dashboard = `<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Chip Counter PC 수신 설정</title><style>body{font:16px system-ui;background:#f3f4f4;color:#26343b;max-width:760px;margin:32px auto;padding:20px}section{background:white;padding:24px;border-radius:12px;margin:16px 0}input{width:100%;box-sizing:border-box;padding:12px;font:inherit}button{padding:12px 20px;margin-top:12px;font:inherit}code{display:block;background:#eee;padding:12px;word-break:break-all}p{line-height:1.7}#status{white-space:pre-wrap}</style><h1>Chip Counter PC 수신 설정</h1><section><h2>태블릿에 입력할 정보</h2><p>태블릿과 같은 네트워크의 PC 주소 하나를 입력하세요.</p><strong>PC 주소</strong><code id="addresses"></code><p>연결 코드</p><code id="token"></code><p>수신 프로그램 창이 열려 있어야 파일을 받을 수 있습니다. Windows 방화벽 알림이 나타나면 사내 네트워크에서 통신을 허용해 주세요.</p></section><section><h2>Excel 저장 폴더</h2><p>폴더를 바꿔도 이미 받은 파일은 이동하지 않습니다. 이후 새 전송부터 적용됩니다.</p><input id="folder" aria-label="저장 폴더 전체 경로"><button id="save">폴더 설정 저장</button><p id="status" role="status"></p></section><p>PC 수신 완료는 MES 업로드 완료를 의미하지 않습니다. 저장된 Excel 파일을 MES에서 업로드하세요.</p><script>const key=location.hash.slice(1)||sessionStorage.getItem('chip-admin')||'';if(key)sessionStorage.setItem('chip-admin',key);history.replaceState(null,'',location.pathname);const headers={'X-Admin-Token':key,'Content-Type':'application/json'};async function load(){try{const r=await fetch('/settings',{headers}),d=await r.json();if(!r.ok)throw Error(d.message);document.getElementById('addresses').textContent=d.addresses.join('\n')||'PC 네트워크 연결을 확인하세요';document.getElementById('token').textContent=d.config.token;document.getElementById('folder').value=d.config.folder;}catch(e){document.getElementById('status').textContent=e.message}}document.getElementById('save').onclick=async()=>{try{const r=await fetch('/settings',{method:'POST',headers,body:JSON.stringify({folder:document.getElementById('folder').value})}),d=await r.json();if(!r.ok)throw Error(d.message);document.getElementById('status').textContent='저장했습니다: '+d.folder}catch(e){document.getElementById('status').textContent=e.message}};load();</script></html>`
