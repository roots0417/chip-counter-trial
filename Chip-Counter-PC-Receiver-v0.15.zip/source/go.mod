module chip-counter-receiver

go 1.20
