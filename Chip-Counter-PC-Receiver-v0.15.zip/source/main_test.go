package main

import (
	"archive/zip"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func workbook(t *testing.T, model string) []byte {
	t.Helper()
	b := new(bytes.Buffer)
	z := zip.NewWriter(b)
	for _, name := range []string{"[Content_Types].xml", "xl/workbook.xml"} {
		w, _ := z.Create(name)
		w.Write([]byte("<root/>"))
	}
	w, _ := z.Create("xl/worksheets/sheet1.xml")
	fmt.Fprint(w, `<worksheet><sheetData><row>`)
	for _, v := range []string{"측정일시", "기종", "Sheet", "총 수량", "불량 수량", "실제 수량"} {
		fmt.Fprintf(w, `<c t="inlineStr"><is><t>%s</t></is></c>`, v)
	}
	fmt.Fprint(w, `</row><row>`)
	for _, v := range []string{"2026-11-20 09:00:00", model, "000123", "2500", "35", "2465"} {
		fmt.Fprintf(w, `<c t="inlineStr"><is><t>%s</t></is></c>`, v)
	}
	fmt.Fprint(w, `</row></sheetData></worksheet>`)
	z.Close()
	return b.Bytes()
}
func post(t *testing.T, s *Server, id string, b []byte) *httptest.ResponseRecorder {
	t.Helper()
	r := httptest.NewRequest("POST", "/api/v1/uploads", bytes.NewReader(b))
	h := sha256.Sum256(b)
	r.Header.Set("X-Chip-Token", s.cfg.Token)
	r.Header.Set("X-Receiver-ID", s.cfg.ReceiverID)
	r.Header.Set("X-Transfer-ID", id)
	r.Header.Set("X-Content-SHA256", hex.EncodeToString(h[:]))
	w := httptest.NewRecorder()
	s.ServeHTTP(w, r)
	return w
}
func TestDeliveryRetryRestartAndPathChange(t *testing.T) {
	base := t.TempDir()
	s, e := newServer(base)
	if e != nil {
		t.Fatal(e)
	}
	b := workbook(t, "MODEL")
	id := strings.Repeat("a", 32)
	w := post(t, s, id, b)
	if w.Code != 200 {
		t.Fatal(w.Code, w.Body)
	}
	var reply struct {
		Path string `json:"path"`
	}
	json.Unmarshal(w.Body.Bytes(), &reply)
	stored, e := os.ReadFile(reply.Path)
	if e != nil || !bytes.Equal(stored, b) {
		t.Fatal("received file differs", e)
	}
	s, e = newServer(base)
	if e != nil {
		t.Fatal(e)
	}
	w = post(t, s, id, b)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"duplicate":true`) {
		t.Fatal(w.Body)
	}
	if post(t, s, id, workbook(t, "CHANGED")).Code != 409 {
		t.Fatal("id conflict accepted")
	}
	s.cfg.Folder = filepath.Join(base, "new-folder")
	if post(t, s, id, b).Code != 200 {
		t.Fatal("retry after path change failed")
	}
	if _, e = os.Stat(s.cfg.Folder); !os.IsNotExist(e) {
		t.Fatal("retry wrote to new folder")
	}
	w = post(t, s, strings.Repeat("b", 32), b)
	if w.Code != 200 || !strings.Contains(w.Body.String(), "new-folder") {
		t.Fatal(w.Body)
	}
	files, _ := filepath.Glob(filepath.Join(filepath.Dir(reply.Path), "*.xlsx"))
	if len(files) != 1 {
		t.Fatal("duplicate files", files)
	}
}
func TestWriteFailureAndCrashRecovery(t *testing.T) {
	base := t.TempDir()
	s, _ := newServer(base)
	s.cfg.Folder = filepath.Join(base, "blocked")
	os.WriteFile(s.cfg.Folder, []byte("file"), 0600)
	id := strings.Repeat("c", 32)
	b := workbook(t, "MODEL")
	if post(t, s, id, b).Code != 500 {
		t.Fatal("acknowledged failed write")
	}
	os.Remove(s.cfg.Folder)
	w := post(t, s, id, b)
	if w.Code != 200 {
		t.Fatal(w.Body)
	}
	p := filepath.Join(base, "receipts", id+".json")
	data, _ := os.ReadFile(p)
	var receipt Receipt
	json.Unmarshal(data, &receipt)
	receipt.Stored = false
	writeJSON(p, receipt)
	s.cfg.Folder = filepath.Join(base, "changed")
	w = post(t, s, id, b)
	if w.Code != 200 {
		t.Fatal(w.Body)
	}
	files, _ := filepath.Glob(filepath.Join(filepath.Dir(receipt.Path), "*.xlsx"))
	if len(files) != 1 {
		t.Fatal("recovery duplicated file")
	}
}
func TestAuthFormatAndLocalSettings(t *testing.T) {
	s, _ := newServer(t.TempDir())
	b := workbook(t, "MODEL")
	r := httptest.NewRequest("POST", "/api/v1/uploads", bytes.NewReader(b))
	w := httptest.NewRecorder()
	s.ServeHTTP(w, r)
	if w.Code != 401 {
		t.Fatal("unauthorized")
	}
	r = httptest.NewRequest("GET", "/", nil)
	r.RemoteAddr = "192.168.1.5:5555"
	w = httptest.NewRecorder()
	s.ServeHTTP(w, r)
	if w.Code != 403 {
		t.Fatal("remote dashboard")
	}
	r = httptest.NewRequest("GET", "/settings", nil)
	r.RemoteAddr = "127.0.0.1:5555"
	w = httptest.NewRecorder()
	s.ServeHTTP(w, r)
	if w.Code != 403 {
		t.Fatal("admin token")
	}
	folder := filepath.Join(t.TempDir(), "새 폴더")
	body, _ := json.Marshal(map[string]string{"folder": folder})
	r = httptest.NewRequest("POST", "/settings", bytes.NewReader(body))
	r.RemoteAddr = "127.0.0.1:5555"
	r.Header.Set("X-Admin-Token", s.admin)
	w = httptest.NewRecorder()
	s.ServeHTTP(w, r)
	if w.Code != 200 || s.cfg.Folder != folder {
		t.Fatal(w.Body)
	}
	if _, e := validateWorkbook([]byte("not a workbook")); e == nil {
		t.Fatal("invalid file accepted")
	}
	if _, e := validateWorkbook(b); e != nil {
		t.Fatal(e)
	}
}
